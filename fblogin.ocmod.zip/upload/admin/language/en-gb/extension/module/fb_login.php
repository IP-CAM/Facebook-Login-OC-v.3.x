<?php

$_['heading_title'] 	= 'Facebook Login';
$_['text_edit'] 		= 'Edit module Facebook Login';

$_['entry_app_id'] 		= 'Facebook APP ID';
$_['entry_app_info']    = '<a href="https://developers.facebook.com/docs/apps/register" target="_blank"><i class="fa fa-question-circle"></i></a>';
$_['entry_app_loc'] 	= 'Language Tag (en_GB)';
$_['entry_status'] 		= 'Status';

$_['text_extension']    = 'Modules';
$_['text_success']      = 'Success: You have modified module Facebook Login';

$_['error_permission'] 	= 'Warning: You do not have permission to modify module Facebook Login!';
$_['error_app_id'] 		= 'Warning: Facebook APP ID required!';
$_['error_loc'] 		= 'Warning: Language Tag required!';
