<?php
$_['error_email'] 		= 'Error no email get from Facebook';
$_['error_fname'] 		= 'Error no first name get from Facebook';
$_['error_lname'] 		= 'Error no last name get from Facebook';
$_['error_fb_id'] 		= 'Error no id user get from Facebook';
$_['error_register'] 	= 'Error register user';
$_['error_login'] 		= 'Error the default password has been changed, access with email and password';
$_['error_auth_error']  = 'Authorization cancelled.';
$_['text_facebook']     = 'Login with Facebook';
