<?php
$_['error_email'] 		= 'Iš Facebook negautas el. pašto adresas.';
$_['error_fname'] 		= 'Iš Facebook negautas vardas.';
$_['error_lname'] 		= 'Iš Facebook negauta pavardė.';
$_['error_fb_id'] 		= 'Iš Facebook negautas vartotojo ID.';
$_['error_register'] 	= 'Klaida registruojant naują paskyrą.';
$_['error_login'] 		= 'Numatytas vartotojo slaptažodis pakeistas, prisijunkite naudodami el. paštą ir slaptažodį.';
$_['error_auth_error']  = 'Prisijungimas atšauktas.';

$_['text_facebook']     = 'Prisijungti su Facebook';
