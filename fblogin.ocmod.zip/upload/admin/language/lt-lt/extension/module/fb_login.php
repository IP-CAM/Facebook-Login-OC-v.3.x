<?php

$_['heading_title'] 	= 'Facebook Prisijungimas';
$_['text_edit'] 		= 'Koreguoti Facebook Prisijungimo modulį';

$_['entry_app_id'] 		= 'Facebook APP ID';
$_['entry_app_info']    = '<a href="https://developers.facebook.com/docs/apps/register" target="_blank"><i class="fa fa-question-circle"></i></a>';
$_['entry_app_loc'] 	= 'Kalbos žymė (en_GB)';
$_['entry_status'] 		= 'Būsena';

$_['text_extension']    = 'Moduliai';
$_['text_success']      = 'Pavyko: Jūs modifikavote Facebook Prisijungimo modulį!';

$_['error_permission'] 	= 'Įspėjimas: Jūs neturite teisių koreguoti Facebook Prisijungimo modulį!';
$_['error_app_id'] 		= 'Įspėjimas: Neįvestas Facebook APP ID!';
$_['error_loc'] 		= 'Įspėjimas: Neįvesta kalbos žymė!';
